package com.example.tictactoe.R


import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.game.tictactoe.R

class MainActivity : AppCompatActivity() {
    private lateinit var buttons: Array<Array<Button>>
    private var playerTurn = true // true for Player X, false for Player O
    private var boardStatus = Array(3) { IntArray(3) }
    private lateinit var status: TextView
    private lateinit var textToSpeech: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Ensure this matches the XML layout file

        status = findViewById(R.id.status)
        textToSpeech = TextToSpeech(this) { }

        buttons = Array(3) { r ->
            Array(3) { c ->
                initButton(r, c)
            }
        }

        initializeBoardStatus()

        val resetButton: Button = findViewById(R.id.resetButton)
        resetButton.setOnClickListener {
            playerTurn = true
            initializeBoardStatus()
            updateStatus("Player X Turn")
            speak("Player X Turn")
        }
    }

    private fun initButton(r: Int, c: Int): Button {
        val button: Button = findViewById(resources.getIdentifier("button$r$c", "id", packageName))
        button.setOnClickListener {
            if (boardStatus[r][c] == -1) {
                boardStatus[r][c] = if (playerTurn) 1 else 0
                button.text = if (playerTurn) "X" else "O"
                button.isEnabled = false
                speak(if (playerTurn) "X" else "O")
                playerTurn = !playerTurn
                updateStatus()
            }
        }
        return button
    }

    private fun updateStatus() {
        when (checkWinner()) {
            1 -> {
                updateStatus("Player X Wins!")
                speak("Player X Wins!")
            }
            0 -> {
                updateStatus("Player O Wins!")
                speak("Player O Wins!")
            }
            else -> {
                if (isBoardFull()) {
                    updateStatus("Game Draw!")
                    speak("Game Draw!")
                } else {
                    val turnText = if (playerTurn) "Player X Turn" else "Player O Turn"
                    updateStatus(turnText)
                    speak(turnText)
                }
            }
        }
    }

    private fun updateStatus(text: String) {
        status.text = text
    }

    private fun speak(text: String) {
        textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    private fun initializeBoardStatus() {
        for (i in 0..2) {
            for (j in 0..2) {
                boardStatus[i][j] = -1
                buttons[i][j].apply {
                    text = ""
                    isEnabled = true
                }
            }
        }
    }

    private fun checkWinner(): Int {
        // Check rows and columns
        for (i in 0..2) {
            if (boardStatus[i][0] == boardStatus[i][1] && boardStatus[i][0] == boardStatus[i][2] && boardStatus[i][0] != -1) {
                return boardStatus[i][0]
            }
            if (boardStatus[0][i] == boardStatus[1][i] && boardStatus[0][i] == boardStatus[2][i] && boardStatus[0][i] != -1) {
                return boardStatus[0][i]
            }
        }
        // Check diagonals
        if (boardStatus[0][0] == boardStatus[1][1] && boardStatus[0][0] == boardStatus[2][2] && boardStatus[0][0] != -1) {
            return boardStatus[0][0]
        }
        if (boardStatus[0][2] == boardStatus[1][1] && boardStatus[0][2] == boardStatus[2][0] && boardStatus[0][2] != -1) {
            return boardStatus[0][2]
        }
        return -1
    }

    private fun isBoardFull(): Boolean {
        for (i in 0..2) {
            for (j in 0..2) {
                if (boardStatus[i][j] == -1) {
                    return false
                }
            }
        }
        return true
    }

    override fun onDestroy() {
        super.onDestroy()
        textToSpeech.shutdown()
    }
}
