package com.example.compareapp.R // Ensure this matches your package name

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.game.smaller_greater.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Change button background color
        val compareButton = findViewById<Button>(R.id.compareButton)
        compareButton.setBackgroundColor(ContextCompat.getColor(this, R.color.buttonColor))

        // Set TextView text color
        val resultText = findViewById<TextView>(R.id.resultText)
        resultText.setTextColor(ContextCompat.getColor(this, R.color.textColorPrimary))

        // Get references to UI elements
        val number1EditText = findViewById<EditText>(R.id.number1)
        val number2EditText = findViewById<EditText>(R.id.number2)
        val resultTextView = findViewById<TextView>(R.id.resultText)

        // Set up the button click listener
        compareButton.setOnClickListener {
            // Get the input numbers
            val number1 = number1EditText.text.toString().toIntOrNull()
            val number2 = number2EditText.text.toString().toIntOrNull()

            // Check if input is valid
            if (number1 != null && number2 != null) {
                val smaller = if (number1 < number2) number1 else number2
                val greater = if (number1 > number2) number1 else number2
                // Display the result
                resultTextView.text = "Smaller number: $smaller\nGreater number: $greater"
            } else {
                resultTextView.text = "Please enter valid numbers."
            }
        }
    }
}
